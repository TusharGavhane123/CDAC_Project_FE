
import Head from "./Heading/Head"
import Login from "./Login/Login"
import Grid from "./Grid/Grid"
function App() {
  return (
    <div>
     {/* <Head/> */}
      {/* <Login/> */}
      
      <Grid/>
    </div>
  );
}

export default App;
