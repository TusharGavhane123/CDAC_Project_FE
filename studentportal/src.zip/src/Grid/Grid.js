import "./Grid.css";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function Grid(){
    return(
        <div>
            <Container>
      <Row className="row" style={{height:10}}>
        <Col className="col" id="one"><img src="./image/logo.jpg" className="img1" /></Col>
        <Col className="col" id="two"><h2>E-Vidyalay</h2></Col>
        <Col className="col" id="three"><img src="./image/cdac.jpg" className="img2" /></Col>
      </Row>
      <Row className="row1">
        <Col  className="col1"><span className="s">Student Portal </span></Col>
        <Col  className="col1"></Col>
        <Col  className="col1"><span className="about"><a href="#">About Us</a> &nbsp; &nbsp; &nbsp;
        <a href="#">Login</a>  </span></Col>
      </Row>
    
      
    </Container>

        </div>
    )
}

export default Grid;